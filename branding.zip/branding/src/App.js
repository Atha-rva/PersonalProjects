import './App.css';

function App() {
  return (
    <>
      <div className="back1">
        <nav className='container'>
          <div className="logo">
            <img src="/Images/brand_logo.png" alt="logo"/>
          </div>

          <ul>
            <li href="#">Menu</li>
            <li href="#">Location</li>
            <li href="#">Home</li>
            <li href="#">Contact</li>
          </ul>

          <button>Login</button>
        </nav>
      /</div>
    </>
  );
}

export default App;
